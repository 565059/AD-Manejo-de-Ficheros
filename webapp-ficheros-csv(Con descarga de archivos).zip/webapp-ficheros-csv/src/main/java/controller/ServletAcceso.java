package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import servicios.ConexionCSV;
import servicios.ConexionXLS;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

import com.opencsv.exceptions.CsvValidationException;

import entities.Ubicacion;

/**
 * Servlet implementation class ServletAcceso
 */
@WebServlet("/ServletAcceso")
public class ServletAcceso extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ServletAcceso() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String boton = request.getParameter("boton");
		String page = "";
		ArrayList<Ubicacion> datos = null;
		System.out.println("Ruta2: " + getServletContext().getRealPath("/"));
		
		
		
		try {
			// Url con la foto
			URL url = new URL(
					"https://datos.alcobendas.org/dataset/5fb50fff-d42c-406e-a183-99865924209b/resource/ed7b0722-ae29-491e-9eab-0549e0963aa2/download/desfibriladores-en-alcobendas.csv");

			// establecemos conexion
			URLConnection urlCon = url.openConnection();

			// Sacamos por pantalla el tipo de fichero
			System.out.println("AAA" + urlCon.getContentType());

			// Se obtiene el inputStream de la foto web y se abre el fichero
			// local.
			InputStream is = urlCon.getInputStream();
			FileOutputStream fos = new FileOutputStream(getServletContext().getRealPath("/") + "datos.csv");

			// Lectura de la foto de la web y escritura en fichero local
			byte[] array = new byte[1000]; // buffer temporal de lectura.
			int leido = is.read(array);
			while (leido > 0) {
				fos.write(array, 0, leido);
				leido = is.read(array);
			}

			// cierre de conexion y fichero.
			is.close();
			fos.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
		
		
		
		
		
		if (boton == null) {
			return;
		}
		
		switch (boton) {
		case "Volver":
			page = "acceso.jsp";
			break;

		case "Enviar":
			String formato = request.getParameter("formato");
			String tipo = request.getParameter("accion");
			if (tipo.equals("lectura")) {
				switch (formato) {
				case "CSV":
					ConexionCSV con = new ConexionCSV();
					try {
						
						datos = con.read(getServletContext());
						
					} catch (CsvValidationException | NumberFormatException | IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				default:
					// no controlado
					break;
				}
				page = "resultados.jsp";
			} else {
				if (!request.getParameter("nombre").isEmpty()) {
					String nombre = request.getParameter("nombre");
					String distrito = request.getParameter("distrito");
					String calle = request.getParameter("calle");
					String numero = request.getParameter("numero");
					String localidad = request.getParameter("localidad");
					Double latitud = !request.getParameter("latitud").isEmpty()
							? Double.parseDouble(request.getParameter("latitud"))
							: null;
					Double longitud = !request.getParameter("longitud").isEmpty()
							? Double.parseDouble(request.getParameter("longitud"))
							: null;
					switch (formato) {
					case "CSV":
						ConexionCSV con = new ConexionCSV();
						try {
							con.write(new Ubicacion(nombre, distrito, calle, numero, localidad, latitud, longitud));
							datos = con.read(getServletContext());
						} catch (CsvValidationException | NumberFormatException | IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						page = "resultados.jsp";
						break;
					default:
						// no controlado
						break;
					}
				}
			}
			break;
		default:
		}
		request.setAttribute("datos", datos);
		request.getRequestDispatcher(page).forward(request, response);
	}

}
